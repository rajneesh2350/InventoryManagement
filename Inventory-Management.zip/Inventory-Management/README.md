# Inventory-Management-Project
Creating a simple web-based inventory management system by using PHP and JavaScript.


ID : admin
Password : Terminator@12345
or signup and create a new admin and change in table `users_info`
 put 1 in is_admin